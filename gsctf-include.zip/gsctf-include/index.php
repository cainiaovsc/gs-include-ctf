<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="css/index.css">
    <title>GS文件包伪协议靶场</title>
</head>
<body>
<ul id = "less">
    <li><a href="less1/less1.php?page=mainPage.php">Less-1</a></li>
    <li><a href="less2/less2.php?page=mainPage.php">Less-2</a></li>
    <li><a href="less3/less3.php?page=mainPage.php">Less-3</a></li>
</ul>
</body>