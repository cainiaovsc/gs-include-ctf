<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../css/mainPage.css">
    <title>GS文件包伪协议靶场</title>
</head>
<div id="border">
    <div>mainPage.php</div>
    <div id="welcome">欢迎来到文件包含伪协议靶场，利用伪协议来获取flag吧！
    <br>
    <div>flag都在当前目录哦！</div></div>
</div>
</html>